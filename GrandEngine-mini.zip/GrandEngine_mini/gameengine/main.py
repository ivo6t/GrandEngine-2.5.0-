import pygame
import os
from game_engine.core import all

pygame.init()
screen = pygame.display.set_mode((400, 400))  # Make sure this line is **before** you use screen

x, y = 100, 100
speed = 4

script_path = os.path.join("scripts", "user_script.py")
with open(script_path) as f:
    user_code = f.read()

globals_dict = {"all": all, "x": x, "y": y, "speed": speed}

exec(user_code, globals_dict)

run = True
while run:
    all.fps(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    x, y = globals_dict["update"](x, y, speed)

    all.screen.clear(screen, all.colors.red())  # screen is defined here
    all.shapes.rect(screen, all.colors.l_yellow(), x, y, 34, 34)
    pygame.display.update()

pygame.quit()
