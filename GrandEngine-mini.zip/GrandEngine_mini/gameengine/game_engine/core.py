import pygame
import random

pygame.init()

class GN():
    clock = pygame.time.Clock()
    keys = []
    class shapes():
        @staticmethod
        def rect(surface,color,x,y,w,h):
            pygame.draw.rect(surface,color,(x,y,w,h))
        @staticmethod
        def circ(surface,color,x,y,radius):
            pygame.draw.circle(surface,color,(x,y),radius)
        @staticmethod
        def Rect(x,y,w,h):
            return pygame.Rect(x,y,w,h)
        
    class colors:
        @staticmethod
        def red():
            return (255,0,0)
        @staticmethod  
        def green():
            return (0,255,0)
        @staticmethod
        def blue():
            return (0,0,255)
        @staticmethod
        def yellow():
            return (255,255,0)
        @staticmethod
        def l_yellow():
            """"light yellow,dark shade"""
            return (125,125,0)

    class screen():
        @staticmethod
        def clear(surface,color):
           surface.fill(color)
        @staticmethod
        def update():
            return pygame.display.update()

    class Img:
       @staticmethod
       def image_l(file):
           return pygame.image.load("assets/" + file)
       @staticmethod
       def img_r(surface,img, x,y):
           surface.blit(img,(x,y))

    class input:
        @staticmethod
        def get():
            GN.keys = pygame.key.get_pressed()  # update keys here every frame
            return GN.keys   

        @staticmethod
        def up():
            return GN.keys[pygame.K_UP] or GN.keys[pygame.K_w]
        @staticmethod
        def down():
            return GN.keys[pygame.K_DOWN] or GN.keys[pygame.K_s]
        @staticmethod
        def left():
            return GN.keys[pygame.K_LEFT] or GN.keys[pygame.K_a]
        @staticmethod
        def right():
            return GN.keys[pygame.K_RIGHT] or GN.keys[pygame.K_d]

    @staticmethod        
    def fps(fps):
        GN.clock.tick(fps)
    
    class Sound:
        @staticmethod
        def load(file):
            return pygame.mixer.Sound("assets/" + file)

        @staticmethod
        def play(sound):
            sound.play()

        @staticmethod
        def stop(sound):
            sound.stop()

        @staticmethod
        def set_volume(sound, vol):
            sound.set_volume(vol)

    class window():
        @staticmethod
        def window_start(code):
            run = True
            while run:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        run = False

                code()
                GN.screen.update()
                GN.fps(60)

        @staticmethod
        def window_close():
            pygame.quit()

        @staticmethod
        def CreateWindow(w,h):
            return pygame.display.set_mode((w,h))
    
    class mouse:
        @staticmethod
        def mouseStart(code):
            for event in pygame.event.get():
                code(event)
    class text:
        my_font = pygame.font.SysFont(None, 24)

        @staticmethod
        def set_font(font_name, size):
            GN.text.my_font = pygame.font.SysFont(font_name, size)

        @staticmethod
        def render_text(text_str, color):
            return GN.text.my_font.render(text_str, False, color)

        @staticmethod
        def draw_text(target_surface, rendered_text, x, y):
            target_surface.blit(rendered_text, (x, y))


class math():            
    class calc:
        @staticmethod
        def adding(num1,num2):
            return num1 + num2
        @staticmethod
        def subtraction(num1,num2):
            return num1 - num2
        @staticmethod
        def multiplication(num1,num2):
            return num1 * num2
        @staticmethod
        def dividing(num1,num2):
            if num2 == 0:
                print("error: impossible to divide by 0")
                return None
            else:
              return num1 / num2  
        @staticmethod
        def pwr(num1,n):
            return num1 ** n

class rm():
    @staticmethod
    def random():
        return random.random()
    @staticmethod
    def random_ch(object):
        return random.choice(object)
    @staticmethod
    def random_int(min,max):
        return random.randint(min,max)
    
class Collision:
    def __init__(self,x,y,w,h):
        self.rect = GN.shapes.Rect(x,y,w,h)
    def move(self,dx,dy):
        self.rect.x += dx
        self.rect.y += dy
    def set_position(self,x,y):
        self.rect.topleft = (x,y)
    def collision(self,other_object):
        return self.rect.colliderect(other_object.rect)