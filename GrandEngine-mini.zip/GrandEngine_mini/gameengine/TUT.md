Grand Engine (GN) — Full Quickstart Tutorial v2.0.6

Welcome to Grand Engine (GN)! This tutorial covers everything you need to get started: creating a window, drawing shapes, input handling, text rendering, sounds, math utilities, random utilities, and running your game loop.
1. Setup and Create a Window

import pygame
from game_engine.core import GN

# Create a 700x700 window
screen = GN.window.CreateWindow(700, 700)

2. Define Your Game Update Function

This function runs every frame. Put your game logic here:

def update():
    # Clear screen with blue color
    GN.screen.clear(screen, GN.colors.blue())

    # Draw a red rectangle at (50, 50) with size 100x100
    GN.shapes.rect(screen, GN.colors.red(), 50, 50, 100, 100)

    # Draw a green circle at (200, 200) with radius 40
    GN.shapes.circ(screen, GN.colors.green(), 200, 200, 40)

    # Update keyboard input state
    GN.input.get()

    # Detect arrow or WASD keys
    if GN.input.up():
        print("Up pressed")
    if GN.input.left():
        print("Left pressed")

3. Handle Mouse Input

Create a function to handle mouse events:

def handle_mouse(event):
    if event.type == pygame.MOUSEBUTTONDOWN:
        print(f"Mouse clicked at {event.pos}")

Use it with:

GN.mouse.mouseStart(handle_mouse)

4. Render Text

Set your font once:

GN.text.font("Arial", 30)

Render and draw text inside your update function:

text_surface = GN.text.text_area("Hello World!", GN.colors.yellow())
GN.text.textRender(screen, text_surface, 100, 100)

5. Play Sounds

Load and play sounds from your assets folder:

click_sound = GN.Sound.load("click.wav")
GN.Sound.play(click_sound)

6. Use Math Utilities

Import math and use the calculator functions:

from game_engine.core import math

print(math.calc.adding(5, 3))          # Output: 8
print(math.calc.pwr(2, 4))             # Output: 16
print(math.calc.dividing(10, 0))       # Prints error, returns None

7. Use Random Utilities

Import and use random helpers:

from game_engine.core import rm

print(rm.random())                     # float between 0.0 and 1.0
print(rm.random_ch([1, 2, 3]))    # random element from list
print(rm.random_int(5, 10))            # random int between 5 and 10

8. Start the Game Loop

To start your game loop simply do:

GN.window.window_start(update)
GN.window.window_close()

9. Custom Game Loop (Optional)

If you want to handle mouse events separately:

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    GN.mouse.mouseStart(handle_mouse)  # Handle mouse events
    update()                          # Run your update logic
    GN.screen.update()                # Update the display
    GN.fps(60)                       # Cap at 60 FPS

GN.window.window_close()

Tips and Tricks

    Always call GN.input.get() every frame to update keyboard states.

    Initialize fonts once with GN.text.font() before rendering text.

    Put all your drawing calls inside your update function.

    Store your assets (images, sounds) in the assets folder.

    Use GN.fps(60) to keep your game running smoothly at 60 frames per second.

    Use the math.calc and rm classes for math and randomness utilities.

Enjoy building your games with Grand Engine! If you have any questions or ideas, keep experimenting and have fun! And please follow me on YouTube by the user "Grand Engine" or by " www.youtube.com/@GrandEngine-ivo6t". Thanks a lot and which ❤️ from Ivo6t

Created by [ivo6t]