from game_engine.core import GN, math, rm, Collision
from game_engine.preBuild import player
from game_engine.colors import Colors
from extensions.core_extensions.math_ext import Math

screen = GN.window.CreateWindow(800, 600)

x, y = 100, 100
speed = 5
score = 0
gravity_y = 0
h = 0.2
balls = []

for _ in range(5):
    balls.append({
        "x": rm.random_int(100, 700),
        "y": rm.random_int(100, 500),
        "radius": 20
    })

def spawn_ball():
    balls.append({
        "x": rm.random_int(50, 750),
        "y": rm.random_int(50, 550),
        "radius": 20
    })

def mouse_events(event):
    if event.type == GN.pygame.MOUSEBUTTONDOWN:
        spawn_ball()

def update():
    global x, y, gravity_y, score

    # Gravity acceleration derivative is constant 9.81
    gravity_y = Math.Eul(gravity_y, 0, h, lambda x, y: 9.81)

    y += gravity_y * h

    x, y = player.input.GNInput(x, y, speed)

    # Clamp y to bottom of window (so player doesn't fall off)
    if y > 550:
        y = 550
        gravity_y = 0

    GN.screen.clear(screen, Colors.navy())

    player_rect = Collision(x, y, 50, 50)
    GN.shapes.rect(screen, Colors.green(), x, y, 50, 50)

    for ball in balls[:]:
        GN.shapes.circ(screen, Colors.orange(), ball["x"], ball["y"], ball["radius"])
        ball_rect = Collision(ball["x"], ball["y"], ball["radius"]*2, ball["radius"]*2)
        if player_rect.collision(ball_rect):
            balls.remove(ball)
            score = math.calc.adding(score, 1)

    score_txt = GN.text.render_text(f"Score: {score}", Colors.yellow())
    GN.text.draw_text(screen, score_txt, 10, 10)

    GN.mouse.mouseStart(mouse_events)

GN.window.window_start(update)
GN.window.window_close()
